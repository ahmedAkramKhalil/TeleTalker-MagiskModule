#!/system/bin/sh
# Enhanced mixer detection script with better error handling and broader device support

set -e  # Exit on any error

LOGFILE="/data/local/tmp/call_injector/mixer_config.txt"
LOGDIR="/data/local/tmp/call_injector"
MIXER_CONTROL=""
DEVICE_ID=""
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_VENDOR=$(getprop ro.product.vendor)

# Create directory if it doesn't exist
mkdir -p "$LOGDIR"

# Function to log messages
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" | tee -a "$LOGFILE"
}

# Function to test mixer control safely
test_mixer() {
    local control="$1"
    log_message "Testing mixer control: $control"
    
    # Check if control exists first
    if ! tinymix | grep -q "$control"; then
        log_message "Control '$control' not found in mixer"
        return 1
    fi
    
    # Try to set it to 1 and then back to 0
    if tinymix "$control" 1 2>/dev/null && tinymix "$control" 0 2>/dev/null; then
        log_message "Control '$control' test successful"
        return 0
    else
        log_message "Control '$control' test failed"
        return 1
    fi
}

# Function to get device ID from multimedia name
get_device_id() {
    local mm="$1"
    case $mm in
        "MultiMedia1") echo "0" ;;
        "MultiMedia2") echo "1" ;;
        "MultiMedia5") echo "12" ;;
        "MultiMedia9") echo "14" ;;
        "MultiMedia3") echo "2" ;;
        "MultiMedia4") echo "3" ;;
        "MultiMedia6") echo "13" ;;
        "MultiMedia7") echo "15" ;;
        "MultiMedia8") echo "16" ;;
        *) echo "0" ;;  # Default fallback
    esac
}

# Check if tinymix is available
if ! command -v tinymix >/dev/null 2>&1; then
    log_message "ERROR: tinymix not found. Audio injection not supported on this device."
    exit 1
fi

log_message "Starting mixer detection on $DEVICE_VENDOR $DEVICE_MODEL"
log_message "Available mixer controls:"
tinymix | head -20 >> "$LOGFILE"

# Extended list of multimedia devices to test
MM_DEVICES="MultiMedia1 MultiMedia2 MultiMedia3 MultiMedia4 MultiMedia5 MultiMedia6 MultiMedia7 MultiMedia8 MultiMedia9"

# Test Incall_Music controls first (most common)
log_message "Testing Incall_Music Audio Mixer controls..."
for mm in $MM_DEVICES; do
    control="Incall_Music Audio Mixer $mm"
    if test_mixer "$control"; then
        MIXER_CONTROL="$control"
        DEVICE_ID=$(get_device_id "$mm")
        log_message "Found working control: $MIXER_CONTROL with device ID: $DEVICE_ID"
        break
    fi
done

# If not found, try Incall_Music_2
if [ -z "$MIXER_CONTROL" ]; then
    log_message "Testing Incall_Music_2 Audio Mixer controls..."
    for mm in $MM_DEVICES; do
        control="Incall_Music_2 Audio Mixer $mm"
        if test_mixer "$control"; then
            MIXER_CONTROL="$control"
            DEVICE_ID=$(get_device_id "$mm")
            log_message "Found working control: $MIXER_CONTROL with device ID: $DEVICE_ID"
            break
        fi
    done
fi

# Try alternative naming patterns for different vendors
if [ -z "$MIXER_CONTROL" ]; then
    log_message "Testing alternative mixer control patterns..."
    
    # Samsung/Exynos patterns
    for mm in $MM_DEVICES; do
        control="CALL_REC Audio Mixer $mm"
        if test_mixer "$control"; then
            MIXER_CONTROL="$control"
            DEVICE_ID=$(get_device_id "$mm")
            break
        fi
    done
    
    # MediaTek patterns
    if [ -z "$MIXER_CONTROL" ]; then
        for mm in $MM_DEVICES; do
            control="CALL_RECORD Audio Mixer $mm"
            if test_mixer "$control"; then
                MIXER_CONTROL="$control"
                DEVICE_ID=$(get_device_id "$mm")
                break
            fi
        done
    fi
fi

# Create configuration file
cat > "$LOGFILE" << EOF
# Mixer configuration for $DEVICE_VENDOR $DEVICE_MODEL
# Generated on $(date)
MIXER_CONTROL="$MIXER_CONTROL"
DEVICE_ID="$DEVICE_ID"
DETECTION_SUCCESS=$([ -n "$MIXER_CONTROL" ] && echo "true" || echo "false")
DEVICE_MODEL="$DEVICE_MODEL"
DEVICE_VENDOR="$DEVICE_VENDOR"
EOF

if [ -n "$MIXER_CONTROL" ]; then
    log_message "SUCCESS: Detection complete."
    log_message "Mixer Control: $MIXER_CONTROL"
    log_message "Device ID: $DEVICE_ID"
    
    # Test the configuration once more to be sure
    if test_mixer "$MIXER_CONTROL"; then
        log_message "Final validation successful"
        exit 0
    else
        log_message "ERROR: Final validation failed"
        exit 1
    fi
else
    log_message "ERROR: No compatible mixer control found"
    log_message "This device may not support audio injection"
    
    # Dump all available controls for debugging
    log_message "All available mixer controls:"
    tinymix >> "$LOGFILE" 2>&1
    
    exit 1
fi